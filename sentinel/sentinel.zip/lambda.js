const fetch = require('node-fetch')
module.exports = function lambda (event, context, callback) {
  console.log(event, context, callback)
  return fetch('http://google.com')
  .then((response) => {
    console.log(response.statusCode)
    callback(null, response)
  })
}
