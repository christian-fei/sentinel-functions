const lambda = require('./lambda')

exports.handler = lambda
