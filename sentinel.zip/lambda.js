module.exports = function lambda (event, callback) {
  callback(null, event)
}
