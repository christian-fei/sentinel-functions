'use strict'

module.exports = () => {}
